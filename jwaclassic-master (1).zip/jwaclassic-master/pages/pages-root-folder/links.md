---
#olivier.winter@hotmail.fr
#joel.winter@winte-puillet.fr
layout: page-fullwidth
title: "" #"Contact & Blogs"
subheadline: ""
#teaser: "Get in touch !"
permalink: "/links/"
header:
    image_fullwidth: "banner-delahaye-type-135-135m-chapron.png"

# Trade, Historical Researches, Restoration and Tuning especially for Delage, Delahaye and Talbot-Lago.
# More pictures and resources on these Blogs:
---


## External Links

<div class="row">
  <div class="large-3 columns"><br>
     <a href="https://www.teamcollection.fr/" title="Team Collection">
        <img src="{{site.baseurl}}/images/logo/teamcollection-fr.png"  width="210" height="150"> Team Collection
     </a>
  </div>
  <div class="large-3 columns"><br>
    <a href="https://www.levoiturist.com/" title="Le Voiturist">
        <img src="{{site.baseurl}}/images/logo/levoiturist.jpg"  width="210" height="150"> Le Voiturist
    </a>
  </div>
  <div class="large-3 columns"><br>
    <a href="http://www.henrichapron.com/Henri_Chapron/Home.html" title="Henri Chapron">
        <img src="{{site.baseurl}}/images/logo/chapron-logo.jpg"  width="210" height="150"><br> Henri Chapron
    </a>
  </div>
  <div class="large-3 columns"><br>
    <a href="https://www.mathieuboisrestaurationautomobile.fr/" title="Mathieu Bois Restoration">
        <img src="{{site.baseurl}}/images/logo/mathieubois-logo.png"  width="210" height="150"> Mathieu Bois Restoration
    </a>
  </div>
</div>
