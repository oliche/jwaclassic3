---
layout: page-fullwidth
show_meta: false
title: "Delahaye 135-MS Coach Figoni"
subheadline: "1951 - Coach Sport Grand Luxe Type 135-MS"
header:
     image_fullwidth: "banner-delahaye-type-135-135ms-figoni.jpg"
permalink: "/delahaye-135-135ms-figoni/"
lang: eng
---

### More pictures and resources on this [*Blog*](https://delahaye135msfigoni.blogspot.com/).

## Overview

![Pic](/images/p-delahaye-135-ms-figoni/delahaye-type-135-135ms-figoni-1.jpg)
![Pic](/images/p-delahaye-135-ms-figoni/delahaye-type-135-135ms-figoni-2.jpg)

## Features
![Pic](/images/p-delahaye-135-ms-figoni/delahaye-type-135-135ms-figoni-3.jpg)


### More pictures and resources on this [*Blog*](https://delahaye135msfigoni.blogspot.com/).


<ul>
    {% for post in site.categories.historique %}
    <li><a href="{{ site.url }}{{ site.baseurl }}{{ post.url }}">{{ post.title }}</a></li>
    {% endfor %}
</ul>
