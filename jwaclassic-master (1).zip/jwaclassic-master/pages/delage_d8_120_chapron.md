---
layout: page-fullwidth
show_meta: false
title: "Delage D8-120 Chapron"
subheadline: "1937 - Cabriolet Grand Luxe"
header:
     image_fullwidth: "banner-delage-d8-120-chapron.jpg"
permalink: "/delage-d8-120-chapron/"
lang: eng
---


## Before


![Pic](/images/p-delage-d8-120-chapron/delage-d8-120-chapron-15.jpg)
![Pic](/images/p-delage-d8-120-chapron/delage-d8-120-chapron-13.jpg)
![Pic](/images/p-delage-d8-120-chapron/delage-d8-120-chapron-10.jpg)

## After


![Pic](/images/p-delage-d8-120-chapron/delage-d8-120-chapron-7.jpg)
![Pic](/images/p-delage-d8-120-chapron/delage-d8-120-chapron-8.jpg)
![Pic](/images/p-delage-d8-120-chapron/delage-d8-120-chapron-9.jpg)
![Pic](/images/p-delage-d8-120-chapron/delage-d8-120-chapron-5.jpg)


<ul>
    {% for post in site.categories.historique %}
    <li><a href="{{ site.url }}{{ site.baseurl }}{{ post.url }}">{{ post.title }}</a></li>
    {% endfor %}
</ul>
