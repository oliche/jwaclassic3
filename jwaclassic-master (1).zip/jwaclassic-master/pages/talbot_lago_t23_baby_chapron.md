---
layout: page-fullwidth
show_meta: false
title: "Talbot-Lago T23 Baby"
subheadline: "1939 - Cabriolet Chapron"
header:
     image_fullwidth: "banner-talbot-lago-t23-chapron-restoration.jpg"
     #image_fullwidth: "banner-talbot-lago-T23-chapron-baby.png"
permalink: "/talbot-lago-t23-baby-chapron/"
lang: eng
---

### More pictures and resources on this [*Blog*](https://talbotlagot23chapron.blogspot.com/).

## Overview
![Pic](/images/p-talbot-lago-t23-baby-chapron/talbot-lago-t23-baby-chapron-3.jpg)
![Pic](/images/p-talbot-lago-t23-baby-chapron/talbot-lago-t23-baby-chapron-2.jpg)

## Before
![Pic](/images/p-talbot-lago-t23-baby-chapron/talbot-lago-t23-baby-chapron-0.jpg)

## After
![Pic](/images/p-talbot-lago-t23-baby-chapron/talbot-lago-t23-baby-chapron-5.jpg)
![Pic](/images/p-talbot-lago-t23-baby-chapron/talbot-lago-t23-baby-chapron-6.jpg)
![Pic](/images/p-talbot-lago-t23-baby-chapron/talbot-lago-t23-baby-chapron-8.jpg)

### More pictures and resources on this [*Blog*](https://talbotlagot23chapron.blogspot.com/).

<ul>
    {% for post in site.categories.historique %}
    <li><a href="{{ site.url }}{{ site.baseurl }}{{ post.url }}">{{ post.title }}</a></li>
    {% endfor %}
</ul>
